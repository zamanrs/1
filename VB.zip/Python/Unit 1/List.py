my_list = ['apple', 'banana', 'cherry']

print("Length of the list:", len(my_list))

my_list.append('date')
print("After appending 'date':", my_list)

my_list.insert(1, 'blueberry')
print("After inserting 'blueberry' at index 1:", my_list)

index_of_cherry = my_list.index('cherry')
print("Index of 'cherry':", index_of_cherry)

my_list.remove('banana')
print("After removing 'banana':", my_list)

del my_list[2]
print("After deleting item at index 2:", my_list)
