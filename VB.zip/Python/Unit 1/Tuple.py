n = (19, 147, 36, 87, 97, 239, 6, 34)

print("Tuple elements:", n)

lowest = min(n)
print("Lowest element:", lowest)

largest = max(n)
print("Largest element:", largest)

difference = largest - lowest
print("Difference between largest and lowest:", difference)
