def filter_even_numbers(numbers):
    return [num for num in numbers if num % 2 == 0]

input_list = [10, 21, 34, 53, 85, 70, 69]
output_list = filter_even_numbers(input_list)
print("Output List:", output_list)
