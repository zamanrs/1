def to_uppercase(s):
    return s.upper()

input_str = "Good Morning, sir."
output_str = to_uppercase(input_str)
print("Output:", output_str)
