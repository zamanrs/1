def reverse_strings(string_list):
    return [s[::-1] for s in string_list]

input_list = ["Anand", "Borsad", "Dakor", "Nadiad"]
output_list = reverse_strings(input_list)
print("Output List:", output_list)
