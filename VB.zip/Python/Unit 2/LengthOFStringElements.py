def get_string_lengths(strings):
    return [len(s) for s in strings]

input_list = ["Anand", "VVN", "Dakor", "Nadiad"]
output_list = get_string_lengths(input_list)
print("Output List:", output_list)
