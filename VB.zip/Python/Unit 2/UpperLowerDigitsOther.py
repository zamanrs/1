def count_characters(s):
    upper = lower = digit = other = 0

    for char in s:
        if char.isupper():
            upper += 1
        elif char.islower():
            lower += 1
        elif char.isdigit():
            digit += 1
        else:
            other += 1

    print("No. of Upper case characters :", upper)
    print("No. of Lower case Characters :", lower)
    print("No. of Digits :", digit)
    print("No. of Other Characters :", other)

input_str = "How Are You, sir?"
count_characters(input_str)
