def get_first_letters(strings):
    return [s[0] for s in strings if s]

input_list = ["Anand", "Borsad", "Dakor", "Nadiad"]
output_list = get_first_letters(input_list)
print("Output List:", output_list)
