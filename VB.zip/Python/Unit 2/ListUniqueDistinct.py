def get_unique_elements(lst):
    unique = []
    seen = set()
    for item in lst:
        if item not in seen:
            unique.append(item)
            seen.add(item)
    return unique

input_list = [1, 2, 3, 3, 3, 3, 4, 4, 4, 5]
output_list = get_unique_elements(input_list)
print("Output List:", output_list)
