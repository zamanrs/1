def separate_odd_even(numbers):
    odd = [num for num in numbers if num % 2 != 0]
    even = [num for num in numbers if num % 2 == 0]
    return odd, even

input_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
odd_list, even_list = separate_odd_even(input_list)

print("Original list of integers:", input_list)
print("Odd numbers list:", odd_list)
print("Even numbers list:", even_list)
