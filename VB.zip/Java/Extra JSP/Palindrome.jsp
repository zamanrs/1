<html>
<head>
    <title>Palindrome Number</title>
</head>
<body>

<h2>Palindrome Number Check</h2>

<form method="post">
    Enter a Number:
    <input type="number" name="num" required>
    <input type="submit" value="Check">
</form>

<%
String input = request.getParameter("num");

if (input != null) {
    int n = Integer.parseInt(input);
    int temp = n;
    int rev = 0;

    while (temp > 0) {
        int r = temp % 10;
        rev = rev * 10 + r;
        temp = temp / 10;
    }

    if (n == rev)
        out.println("<h3>" + n + " is a Palindrome Number</h3>");
    else
        out.println("<h3>" + n + " is not a Palindrome Number</h3>");
}
%>

</body>
</html>