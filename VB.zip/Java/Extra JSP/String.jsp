<html>
<body>

<%
String s = "Hello World";
String s1 = "hello world";


out.println("Original String: " + s + "<br><br>");

out.println("charAt(1): " + s.charAt(1) + "<br>");
out.println("length(): " + s.length() + "<br>");
out.println("toUpperCase(): " + s.toUpperCase() + "<br>");
out.println("toLowerCase(): " + s.toLowerCase() + "<br>");
out.println("equalsIgnoreCase(): " + s.equalsIgnoreCase(s1) + "<br>");
out.println("compareTo(): " + s.compareTo(s1) + "<br>");
out.println("indexOf(): " + s.indexOf("o") + "<br>");
out.println("lastIndexOf(): " + s.lastIndexOf("o") + "<br>");
out.println("substring(6): " + s.substring(6) + "<br>");
out.println("replace(): " + s.replace("o","a") + "<br>");
out.println("Equals: " + s.equals(s1) + "<br>");
out.println("isEmpty(): " + s.isEmpty() + "<br>");
out.println("valueOf(): " + s.valueOf(s1) + "<br>");



%>

</body>
</html>