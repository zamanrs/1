<!DOCTYPE html>
<html>
<head>
    <title>Factorial Program</title>
</head>
<body>

<h2>Find Factorial of a Number</h2>

<form method="post">
    Enter a Number:
    <input type="number" name="num" required>
    <input type="submit" value="Calculate">
</form>

<%
    String str = request.getParameter("num");

    if (str != null) {
        int num = Integer.parseInt(str);
        long factorial = 1;

        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }

        out.println("<h3>Factorial of " + num + " is " + factorial + "</h3>");
    }
%>

</body>
</html>