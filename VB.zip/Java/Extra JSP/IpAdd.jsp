<html>
<head>
	<title>Hello</title>
</head>
<body><br>
<%
   out.println("RS");
   out.println("Your IP Address is"+request.getRemoteAddr());
%>
</body>
</html>
 