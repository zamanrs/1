<html>
<body>

<%!
int areaOfSquare(int side)
{
    return side * side;
}
%>

<%
int side = 5;
out.println("Area of Square = " + areaOfSquare(side));
%>

</body>
</html>