<html>
<body>

<%!
int cube(int n)
{
    return n * n * n;
}
%>
<%
int n = 10;
out.println("Cube = " + cube(n));
%>

</body>
</html>