<html>
<head>
    <title>ex1</title>
</head>
<body>
    <%
    for (int i = 50; i >= 10; i-=5) {
    %>
        <p style="font-size:<%= i %>px;">
            RS
        </p>
    <%
    }
    %>
</body>
</html>