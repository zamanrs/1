<!DOCTYPE html>
<html>
<head>
    <title>Fibonacci Series</title>
</head>
<body>

<%
int n = 10;
int a = 0, b = 1, c;

out.print("Fibonacci Series:<br>");

for (int i = 1; i <= n; i++) {
    out.print(a + " ");
    c = a + b;
    a = b;
    b = c;
}
%>

</body>
</html>