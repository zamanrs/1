<!DOCTYPE html>
<html>
<head>
    <title>Prime Number Check</title>
</head>
<body>

<h2>Prime Number Check</h2>

<form method="post">
    Enter a Number:
    <input type="number" name="num" required>
    <input type="submit" value="Check">
</form>

<%
String input = request.getParameter("num");

if (input != null) {
    int n = Integer.parseInt(input);
    int count = 0;

    for (int i = 1; i <= n; i++) {
        if (n % i == 0)
            count++;
    }

    if (count == 2)
        out.println("<h3>" + n + " is a Prime Number</h3>");
    else
        out.println("<h3>" + n + " is Not a Prime Number</h3>");
}
%>

</body>
</html>