<html>
<body>

<%!
double areaOfCircle(double radius)
{
    return 3.14 * radius * radius;
}
%>
<%
double r = 5;
out.println("Area of Circle = " + areaOfCircle(r));
%>
</body>
</html>