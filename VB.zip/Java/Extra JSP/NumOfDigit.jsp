<!DOCTYPE html>
<html>
<head>
    <title>Count Digits</title>
</head>
<body>

<h2>Count Digits</h2>

<form method="post">
    Enter a Number:
    <input type="number" name="num" required>
    <input type="submit" value="Count">
</form>

<%
String input = request.getParameter("num");

if (input != null) {
    int n = Integer.parseInt(input);
    int count = 0;
    int temp = n;

    if (temp == 0) {
        count = 1;
    } else {
        while (temp > 0) {
            count++;
            temp /= 10;
        }
    }

    out.println("<h3>Number of Digits = " + count + "</h3>");
}
%>

</body>
</html>