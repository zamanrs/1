
<html>
<head>
    <title>Reverse Number</title>
</head>
<body>

<h2>Reverse a Number</h2>

<form method="post">
    Enter a Number:
    <input type="number" name="num" required>
    <input type="submit" value="Reverse">
</form>

<%
String input = request.getParameter("num");

if (input != null) {
    int n = Integer.parseInt(input);
    int rev = 0;
    int temp = n;

    while (temp > 0) {
        int r = temp % 10;
        rev = rev * 10 + r;
        temp = temp / 10;
    }

    out.println("<h3>Reverse Number = " + rev + "</h3>");
}
%>

</body>
</html>