<html>
<head>
    <title>JSP Example</title>
</head>
<body>

<%!
    int cube(int n) {
        return n * n * n;
    }

    double circleArea(double r) {
        return 3.14 * r * r;	
    }

    int rectangleArea(int length, int width) {
        return length * width;
    }
%>

<%
    int number = 10;
    double radius = 5;
    int length = 8;
    int width = 6;
%>

<h2>Find out Area</h2>

Cube of <%= number %> = <%= cube(number) %><br><br>

Circle Area = <%= circleArea(radius) %><br><br>

Rectangle Area = <%= rectangleArea(length, width) %>

</body>
</html>