<html>
<body>
<h2>
<%
String s = "Sardar Patel University";

out.println("String: " + s + "<br><br>");

out.println("length of String : " + s.length() + "<br>");
out.println("After Replacing 'P' by 'R' : " + s.replace("P","R") + "<br>");
out.println("Character in Uppercase : " + s.toUpperCase() + "<br>");
out.println("Extracted String : " + s.substring(0, 6) + "<br>");
%>
</h2>
</body>
</html>