<%@ page import="java.sql.*" %>

<html>
<body>

<h2>Login Form</h2>

<form method="post">

    Username:
    <input type="text" name="username">
    <br><br>

    Password:
    <input type="password" name="password">
    <br><br>

    <input type="submit" value="Login">

</form>

<%
String username = request.getParameter("username");
String password = request.getParameter("password");

if(username != null && password != null)
{
        Class.forName("oracle.jdbc.driver.OracleDriver");

        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:49679:XE","system","1234");

        String sql = "SELECT * FROM login WHERE username=? AND password=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, username);
        ps.setString(2, password);

        ResultSet rs = ps.executeQuery();

        if(rs.next())
        {
            out.println("<h2>Welcome " + username + "</h2>");
            out.println("<h3>Login Successful</h3>");
        }
        else
        {
            out.println("<h3>Invalid Username or Password</h3>");
        }

        rs.close();
        ps.close();
        con.close();
}
%>

</body>
</html>