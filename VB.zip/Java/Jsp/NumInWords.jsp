<html>
<head>
    <title>Number to Words</title>
</head>
<body>

<h2>Convert Number to Words</h2>

<form method="post">
    Enter Number:
    <input type="text" name="num" required>
    <input type="submit" value="Convert">
</form>

<%
String num = request.getParameter("num");
if(num != null)
{
    out.print("<h3>Output: </h3>");

    for(int i = 0; i < num.length(); i++)
    {
        char ch = num.charAt(i);

        switch(ch)
        {
            case '0':
                out.print("Zero ");
                break;
            case '1':
                out.print("One ");
                break;
            case '2':
                out.print("Two ");
                break;
            case '3':
                out.print("Three ");
                break;
            case '4':
                out.print("Four ");
                break;
            case '5':
                out.print("Five ");
                break;
            case '6':
                out.print("Six ");
                break;
            case '7':
                out.print("Seven ");
                break;
            case '8':
                out.print("Eight ");
                break;
            case '9':
                out.print("Nine ");
                break;
            default:
                out.print("Invalid Input ");
        }
    }
}
%>

</body>
</html>