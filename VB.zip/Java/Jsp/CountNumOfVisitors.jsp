<%
Integer count = (Integer)application.getAttribute("visitorCount");
if(count == null){
count = 1;
}
else{
count++;
}
application.setAttribute("visitorCount", count);
out.println("<h2>Welcome to Website</h2>");
out.println("<h3>Number of Visitors: " + count + "</h3>");
%>
