<html>
<body>
<h2>
<%
out.println("Welcome to JSP");
%>
</h2>
</body>
</html>