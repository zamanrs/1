<%@ page import="java.util.Date" %>
<html>
<head>
<meta http-equiv="refresh" content="5">
</head>
<body>
<h2>JSP Auto Refresh Page</h2>
<%
Date d = new Date();
out.println("Current Date and Time: " + d);
%>
<p>This Page Will Refresh Automatically After 5 Seconds.</p>

</body>
</html>
