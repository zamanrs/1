import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UnamePass extends HttpServlet {

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String uname = request.getParameter("username");
        String pass = request.getParameter("password");

        out.println("<html><body>");

        if ("admin".equals(uname) && "admin".equals(pass)) {
            out.println("<h2>Welcome User</h2>");
        } else {
            out.println("<h2>Wrong User Name or Password</h2>");
        }

        out.println("<br><br>");
        out.println("<a href='index.html'>Go Back</a>");
        out.println("</body></html>");
    }
}