import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Arithmatic extends HttpServlet
{
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        int n1 = Integer.parseInt(request.getParameter("num1"));
        int n2 = Integer.parseInt(request.getParameter("num2"));
        String op = request.getParameter("op");
        double result = 0;
        if(op.equals("+"))
        {
            result = n1 + n2;
        }
        else if(op.equals("-"))
        {
            result = n1 - n2;
        }
        else if(op.equals("*"))
        {
            result = n1 * n2;
        }
        else if(op.equals("/"))
        {
            result = (double)n1 / n2;
        }
        out.println("<html><body>");
        out.println("<h2>Result = " + result + "</h2>");
        out.println("<br><a href='index.html'>Go Back</a>");
        out.println("</body></html>");
    }
}