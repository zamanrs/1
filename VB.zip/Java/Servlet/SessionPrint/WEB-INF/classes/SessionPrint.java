import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionPrint extends HttpServlet 
{
    public void doGet(HttpServletRequest req, HttpServletResponse res) 
	                  throws IOException,ServletException {
        HttpSession s1 = req.getSession(true);
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		Date d = new Date(s1.getCreationTime());
        Date l = new Date(s1.getLastAccessedTime());
        String msg = "Welcome back to Servlet Page!";
		Integer visit=0;
        String userId = "name";
		String name = "Raihan";
		String visitId = "visit";
		
        if (s1.isNew()) {
            msg = "Welcome to My New Servlet!";
			visit=1;
            s1.setAttribute(userId, name);
            s1.setAttribute(visitId, visit);
        } else {
            visit = (Integer) s1.getAttribute(visitId);
			if(visit == null)
				visit=1;
			else
				visit=visit+1;
            name = (String)s1.getAttribute(userId);
			s1.setAttribute(visitId, visit);
        }
        out.println("<html><body>");
		out.println("<h2>" + msg + "</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Session</th><th>Values</th></tr>");
        out.println("<tr><td>ID</td><td>" + s1.getId() + "</td></tr>");
        out.println("<tr><td>Creation Time</td><td>" + d + "</td></tr>");
        out.println("<tr><td>Last Access Time</td><td>" + l + "</td></tr>");
        out.println("<tr><td>User Id</td><td>" + name + "</td></tr>");
        out.println("<tr><td>Visit Count</td><td>" + visit + "</td></tr>");
        out.println("</table></body></html>");
    }
}