import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class bg extends HttpServlet
{
    public void doPost(HttpServletRequest req,
                       HttpServletResponse res)
            throws ServletException, IOException
    {
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();

        String color = req.getParameter("color");

        out.println("<html>");
        out.println("<body style='background-color:" + color + ";'>");
        out.println("<h2>Selected Color : " + color + "</h2>");
		out.println("<a href='index.html'>GO BACK</a>");
        out.println("</body>");
        out.println("</html>");
    }
}