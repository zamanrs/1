import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class cookie2 extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        Cookie[] ar = req.getCookies();
        if (ar != null && ar.length > 0) {
            out.println("Hello! " + ar[0].getValue()+ " Welcome to Cookie2!");
        } else {
            out.println("No cookies found.");
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }
}
