import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class cookie extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        String nm = req.getParameter("username");
        Cookie ck = new Cookie("username", nm);
        res.addCookie(ck);

        out.println("<html><body>");
        out.println("Welcome! " + nm);
        out.println("<form action='cookie2' method='POST'>"); 
        out.println("<input type='submit' value='Next'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        doPost(req, res);
    }
}
