import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CheckNumber extends HttpServlet
{
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws IOException, ServletException
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int n = Integer.parseInt(request.getParameter("num"));
        String choice = request.getParameter("choice");

        out.println("<html><body>");

        if(choice.equals("positive"))
        {
            if(n >= 0)
                out.println("<h2>Positive Number</h2>");
            else
                out.println("<h2>Negative Number</h2>");
        }

        else if(choice.equals("odd"))
        {
            if(n % 2 == 0)
                out.println("<h2>Even Number</h2>");
            else
                out.println("<h2>Odd Number</h2>");
        }

        else if(choice.equals("prime"))
        {
            boolean prime = true;

            if(n <= 1)
                prime = false;
            else
            {
                for(int i=2; i<=n/2; i++)
                {
                    if(n%i==0)
                    {
                        prime = false;
                        break;
                    }
                }
            }

            if(prime)
                out.println("<h2>Prime Number</h2>");
            else
                out.println("<h2>Not Prime Number</h2>");
        }

        else if(choice.equals("palindrome"))
        {
            int temp=n, rev=0;

            while(temp!=0)
            {
                rev = rev*10 + temp%10;
                temp = temp/10;
            }

            if(rev==n)
                out.println("<h2>Palindrome Number</h2>");
            else
                out.println("<h2>Not Palindrome Number</h2>");
        }

        else if(choice.equals("armstrong"))
        {
            int temp=n, sum=0;

            while(temp!=0)
            {
                int r=temp%10;
                sum=sum+r*r*r;
                temp=temp/10;
            }

            if(sum==n)
                out.println("<h2>Armstrong Number</h2>");
            else
                out.println("<h2>Not Armstrong Number</h2>");
        }

        else if(choice.equals("fibonacci"))
        {
            int a=0,b=1,c=0;
            boolean fib=false;

            if(n==0 || n==1)
                fib=true;

            while(c<n)
            {
                c=a+b;
                a=b;
                b=c;

                if(c==n)
                {
                    fib=true;
                    break;
                }
            }

            if(fib)
                out.println("<h2>Member of Fibonacci Series</h2>");
            else
                out.println("<h2>Not a Member of Fibonacci Series</h2>");
        }

        out.println("<br><a href='index.html'>Go Back</a>");
        out.println("</body></html>");
    }
}