import java.util.*;

class PrimeORNot{
	public static void main(String are[]){
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter No:");
		int n=sc.nextInt();
		ch ob=new ch(n);
		ob.start();
	}
}
class ch extends Thread{
	int n;
	ch(int n){
		this.n=n;
	}
	public void run(){
		boolean flag=false;
		for(int i=2;i<n;i++){
			if(n%i==0){
				flag=true;
				break;
			}
		}
		if(!flag){
			System.out.print("Prime No");
		}
		else{
			System.out.print("Not Prime No");
		}
	}
}