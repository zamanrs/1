class ThreeThreads{
	public static void main(String ar[]){
		t1 ob1=new t1();
		ob1.setName("Thread-1");
		ob1.start();
		t1 ob2=new t1();
		ob2.setName("Thread-2");
		ob2.start();
	    t1 ob3=new t1();
		ob3.setName("Thread-3");
		ob3.start();
	}
}

class t1 extends Thread{
	public void run(){
		try {
		for(int i=1;i<=3;i++){
			System.out.println(getName() + "=" + i);
            sleep(999);
            }
			System.out.println(getName()+"is Alive"+isAlive());
		}
			catch (InterruptedException e) {
                System.out.println(e);
            }
		}
	}