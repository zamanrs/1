class ThreadA extends Thread {
    public void run() {
        System.out.println("Thread A Started");
        for (int i = 1; i <= 5; i++) {
                System.out.println("From Thread A :I = " + i);
        }
        System.out.println("Exit from A");
    }
}

class ThreadB extends Thread {
    public void run() {
        System.out.println("Thread B Started");
        for (int j = 1; j <= 5; j++) {
            System.out.println("From Thread B :J = " + j);
        }
        System.out.println("Exit from B");
    }
}

class ThreadC extends Thread {
    public void run() {
        System.out.println("Thread C Started");
        for (int k = 1; k <= 5; k++) {
            if (k != 4) {
                System.out.println("From Thread C :K = " + k);
            }
        }
        System.out.println("Exit from C");
    }
}

public class AssignPriority {
    public static void main(String[] args) {
        ThreadA t1 = new ThreadA();
        ThreadB t2 = new ThreadB();
        ThreadC t3 = new ThreadC();

        System.out.println("Started Thread A");
        System.out.println("Started Thread B");
        System.out.println("Started Thread C");

       
        t1.setPriority(Thread.MIN_PRIORITY);  
        t2.setPriority(Thread.NORM_PRIORITY); 
        t3.setPriority(Thread.MAX_PRIORITY);  

      
        t1.start();
        t2.start();
        t3.start();

        System.out.println("End of main Thread");
    }
}