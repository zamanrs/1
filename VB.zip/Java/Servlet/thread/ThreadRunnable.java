class ThreadRunnable{
       public static void main(String args[])
	{
		Thread ob = new Thread(new tr());
		ob.start();
	}
}

class tr implements Runnable
{
	public void run()
	{
		System.out.println("Thread is Running!");
	}
}