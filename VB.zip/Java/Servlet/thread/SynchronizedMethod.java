class table{
	synchronized void PrintTable(int n){
		for(int i=1;i<=5;i++){
			System.out.println(n*i);
			try{
				Thread.sleep(99);
			}
			catch(Exception e){
				System.out.print(e);
			}
		}
	}
}
class tc1 extends Thread{
	table ob;
	tc1(table t){
		ob=t;
	}
	public void run(){
		ob.PrintTable(1);
	}
}
class tc2 extends Thread{
	table ob2;
	tc2(table t2){
		ob2=t2;
	}
	public void run(){
		ob2.PrintTable(10);
	}
}
class SynchronizedMethod{
	public static void main(String ar[]){
		table ob=new table();
		tc1 ob2=new tc1(ob);
		tc2 ob3=new tc2(ob);
		ob2.start();
		ob3.start();
	}
}