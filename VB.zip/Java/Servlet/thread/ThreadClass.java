class ThreadClass{
        public static void main(String args[])
	{
		tc ob = new tc();
		ob.start();
	}
}
class tc extends Thread
{
	public void run()
	{
		System.out.println("New Thread is Run!");
	}
	
}