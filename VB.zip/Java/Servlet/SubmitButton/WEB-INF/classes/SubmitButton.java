import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SubmitButton extends HttpServlet
{
    public void doPost(HttpServletRequest req,
                      HttpServletResponse res)
                      throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html><body>");
        out.println("<h1>Sardar Patel University</h1>");
        out.println("</body></html>");
    }

}